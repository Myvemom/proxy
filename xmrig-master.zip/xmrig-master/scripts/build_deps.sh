#!/bin/bash -e

./build.uv.sh
./build.hwloc.sh
./build.openssl.sh